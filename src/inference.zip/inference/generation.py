import time
from typing import List, Optional, Callable, Dict, Any
from model.model import AetherModel
from tokenizer.tokenizer import AetherTokenizer, EOS_TOKEN_ID, UNK_TOKEN_ID
from inference.sampling import sample_next_token, apply_repetition_penalty, apply_no_repeat_ngram_blocker

class TokenGenerator:
    def __init__(self, model: AetherModel, tokenizer: AetherTokenizer):
        self.model = model
        self.tokenizer = tokenizer

    def generate_tokens(
        self,
        prompt_token_ids: List[int],
        max_tokens: int = 128,
        temperature: float = 0.7,
        top_k: int = 40,
        top_p: float = 0.9,
        repetition_penalty: float = 1.1,
        no_repeat_ngram_size: int = 3,
        stop_token_ids: Optional[List[int]] = None,
        deterministic: bool = False,
        timeout_sec: Optional[float] = None,
        is_cancelled: Optional[Callable[[], bool]] = None
    ) -> List[int]:
        """
        Runs auto-regressive token generation starting from prompt_token_ids.
        Returns list of newly generated token IDs.
        """
        stop_ids = set(stop_token_ids or [EOS_TOKEN_ID, self.tokenizer.token_to_id.get("<eos>", 2)])
        generated_ids: List[int] = []

        if not prompt_token_ids:
            return generated_ids

        start_time = time.time()
        max_seq_len = getattr(self.model.config, "max_seq_len", 256)
        vocab_size = getattr(self.model.config, "vocab_size", len(self.tokenizer.token_to_id))

        # Clamp prompt if oversized
        if len(prompt_token_ids) >= max_seq_len:
            prompt_token_ids = prompt_token_ids[-(max_seq_len - 1):]

        # 1. Populate KV cache for initial prompt sequence in a single parallel pass
        logits, layer_caches = self.model.forward_prompt(prompt_token_ids)
        current_pos = len(prompt_token_ids)

        for step in range(max_tokens):
            if is_cancelled and is_cancelled():
                break

            if timeout_sec is not None and (time.time() - start_time) > timeout_sec:
                break

            if current_pos + step >= max_seq_len:
                break

            # 2. Apply repetition penalty & n-gram loop protection
            penalized_logits = apply_repetition_penalty(logits, generated_ids, penalty=repetition_penalty)
            if no_repeat_ngram_size > 1:
                penalized_logits = apply_no_repeat_ngram_blocker(
                    penalized_logits,
                    generated_ids,
                    ngram_size=no_repeat_ngram_size
                )

            next_token_id = sample_next_token(
                penalized_logits,
                temperature=temperature,
                top_k=top_k,
                top_p=top_p,
                deterministic=deterministic
            )

            # Validate token bounds
            if next_token_id < 0 or next_token_id >= vocab_size:
                next_token_id = UNK_TOKEN_ID

            # 3. Check stop tokens
            if next_token_id in stop_ids:
                break

            generated_ids.append(next_token_id)

            # 4. Advance single step with KV-cache
            if step < max_tokens - 1 and (current_pos + step + 1 < max_seq_len):
                logits, layer_caches = self.model.forward_step(
                    next_token_id,
                    start_pos=current_pos + step,
                    layer_caches=layer_caches
                )

        return generated_ids


