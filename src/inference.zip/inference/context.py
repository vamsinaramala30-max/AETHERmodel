"""
AETHER MODEL — Context Window Manager
Formats prompt history and structured context into standard tokenized boundaries:
SYSTEM -> MEMORY -> RAG EVIDENCE -> PROJECT CONTEXT -> TOOL RESULTS -> CONVERSATION HISTORY -> USER REQUEST -> ASSISTANT
"""

from typing import Dict, Any, List, Optional
from tokenizer.tokenizer import (
    AetherTokenizer,
    SYSTEM_TOKEN_ID,
    USER_TOKEN_ID,
    ASSISTANT_TOKEN_ID,
    TOOL_TOKEN_ID,
    EVIDENCE_TOKEN_ID
)

class ContextManager:
    def __init__(self, tokenizer: AetherTokenizer, max_seq_len: int = 256):
        self.tokenizer = tokenizer
        self.max_seq_len = max_seq_len

    def format_prompt(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> List[int]:
        """
        Formats raw prompt string and contextual data into structured token sequence.
        Context Sequence:
        SYSTEM -> MEMORY -> RAG EVIDENCE -> PROJECT CONTEXT -> TOOL RESULTS -> CONVERSATION HISTORY -> USER REQUEST
        """
        context = context or {}
        token_ids: List[int] = []

        system_prompt = context.get("system_prompt") or context.get("systemPrompt")
        memory_context = context.get("memory_context") or context.get("memoryContext")
        rag_context = context.get("rag_context") or context.get("ragContext")
        project_context = context.get("project_context") or context.get("projectContext")
        tool_results = context.get("tool_results") or context.get("toolResults")
        conversation_history = context.get("conversation_history") or context.get("conversationHistory") or context.get("messages")

        # 1. System prompt
        if system_prompt:
            token_ids.append(SYSTEM_TOKEN_ID)
            token_ids.extend(self.tokenizer.encode(str(system_prompt)))

        # 2. Memory context
        if memory_context:
            token_ids.append(SYSTEM_TOKEN_ID)
            token_ids.extend(self.tokenizer.encode(f"[Memory]: {memory_context}"))

        # 3. Evidence / RAG context
        if rag_context:
            token_ids.append(EVIDENCE_TOKEN_ID)
            token_ids.extend(self.tokenizer.encode(str(rag_context)))

        # 4. Project context
        if project_context:
            token_ids.append(SYSTEM_TOKEN_ID)
            token_ids.extend(self.tokenizer.encode(f"[Project]: {project_context}"))

        # 5. Tool execution results
        if tool_results:
            token_ids.append(TOOL_TOKEN_ID)
            token_ids.extend(self.tokenizer.encode(str(tool_results)))

        # 6. Conversation history (prior turns)
        if conversation_history and isinstance(conversation_history, list):
            for msg in conversation_history:
                role = msg.get("role", "user") if isinstance(msg, dict) else "user"
                content = msg.get("content", "") if isinstance(msg, dict) else str(msg)
                if not content:
                    continue
                if role in ("system", "SYSTEM"):
                    token_ids.append(SYSTEM_TOKEN_ID)
                elif role in ("assistant", "ASSISTANT"):
                    token_ids.append(ASSISTANT_TOKEN_ID)
                else:
                    token_ids.append(USER_TOKEN_ID)
                token_ids.extend(self.tokenizer.encode(content))

        # 7. Current User prompt encoding
        token_ids.append(USER_TOKEN_ID)
        token_ids.extend(self.tokenizer.encode(prompt))

        # 8. Assistant prefix for autoregressive generation
        token_ids.append(ASSISTANT_TOKEN_ID)

        # Truncate to context length bounds keeping prompt and recent context
        if len(token_ids) > self.max_seq_len:
            token_ids = token_ids[-self.max_seq_len:]

        return token_ids

