"""
AETHER MODEL — Logits Sampling Strategy
Provides temperature scaling, top-k filtering, top-p (nucleus) sampling, greedy argmax, and repetition penalty.
"""

import math
import random
import numpy as np
from typing import List, Union

def apply_repetition_penalty(
    logits: Union[np.ndarray, List[float]],
    generated_token_ids: List[int],
    penalty: float = 1.2
) -> List[float]:
    """
    Applies penalty to logits of already generated tokens to reduce repetition.
    """
    if penalty == 1.0 or not generated_token_ids:
        return logits

    if isinstance(logits, np.ndarray):
        arr = logits.copy()
    else:
        arr = np.array(logits, dtype=np.float64)

    seen_ids = [tid for tid in set(generated_token_ids) if 0 <= tid < len(arr)]
    if seen_ids:
        idx = np.array(seen_ids, dtype=np.int64)
        vals = arr[idx]
        arr[idx] = np.where(vals < 0, vals * penalty, vals / penalty)
    return arr

def apply_no_repeat_ngram_blocker(
    logits: Union[np.ndarray, List[float]],
    generated_token_ids: List[int],
    ngram_size: int = 3
) -> np.ndarray:
    """
    Prevents generation of tokens that would create repeated n-grams.
    """
    if isinstance(logits, np.ndarray):
        arr = logits.copy()
    else:
        arr = np.array(logits, dtype=np.float64)

    if ngram_size <= 1 or len(generated_token_ids) < ngram_size - 1:
        return arr

    prefix = tuple(generated_token_ids[-(ngram_size - 1):])
    banned_tokens = set()

    for i in range(len(generated_token_ids) - ngram_size + 1):
        if tuple(generated_token_ids[i:i + ngram_size - 1]) == prefix:
            banned_tokens.add(generated_token_ids[i + ngram_size - 1])

    for banned_tid in banned_tokens:
        if 0 <= banned_tid < len(arr):
            arr[banned_tid] = -1e9

    return arr

def sample_next_token(
    logits: Union[np.ndarray, List[float]],
    temperature: float = 0.7,
    top_k: int = 40,
    top_p: float = 0.9,
    deterministic: bool = False
) -> int:
    """
    Samples the next token index from model output logits.
    """
    arr = np.asarray(logits, dtype=np.float64)
    if arr.size == 0:
        return 0

    # Replace any NaN or inf values safely
    if not np.all(np.isfinite(arr)):
        arr = np.nan_to_num(arr, nan=-1e9, posinf=1e4, neginf=-1e9)

    # Deterministic / Greedy Argmax mode
    if deterministic or temperature <= 0.0:
        return int(np.argmax(arr))

    # Temperature scaling
    scaled = arr / max(temperature, 1e-5)

    # Top-K filtering
    if 0 < top_k < len(scaled):
        partition_idx = np.argpartition(scaled, -top_k)[-top_k:]
        cutoff_val = np.min(scaled[partition_idx])
        scaled[scaled < cutoff_val] = -1e9

    # Softmax conversion to probabilities with numerical stability
    max_logit = np.max(scaled)
    exps = np.exp(np.clip(scaled - max_logit, -50.0, 50.0))
    sum_exps = np.sum(exps)
    if sum_exps <= 0.0 or not np.isfinite(sum_exps):
        return int(np.argmax(arr))
    probs = exps / sum_exps

    # Top-P (Nucleus) filtering
    if top_p < 1.0:
        sorted_indices = np.argsort(probs)[::-1]
        sorted_probs = probs[sorted_indices]
        cum_probs = np.cumsum(sorted_probs)
        cutoff_idx = np.searchsorted(cum_probs, top_p)
        keep_indices = sorted_indices[:cutoff_idx + 1]
        mask = np.zeros_like(probs, dtype=bool)
        mask[keep_indices] = True
        probs[~mask] = 0.0
        sum_p = np.sum(probs)
        if sum_p <= 0.0 or not np.isfinite(sum_p):
            return int(np.argmax(arr))
        probs = probs / sum_p

    # Categorical sampling
    try:
        return int(np.random.choice(len(probs), p=probs))
    except Exception:
        return int(np.argmax(arr))


