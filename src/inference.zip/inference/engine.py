"""
AETHER MODEL — Native AetherInferenceEngine
Unified inference entry point handling prompt context, confidence classification, safety, auto-regressive generation, and streaming.
"""

from typing import Dict, Any, List, Tuple, Generator, Optional
from model.model import AetherModel
from tokenizer.tokenizer import AetherTokenizer
from safety.input_guard import InputGuard
from safety.output_guard import OutputGuard
from inference.context import ContextManager
from inference.generation import TokenGenerator
from inference.streaming import StreamTokenGenerator

class AetherInferenceEngine:
    def __init__(
        self,
        model: Optional[AetherModel] = None,
        tokenizer: Optional[AetherTokenizer] = None
    ):
        if tokenizer is None:
            import os
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            vocab_file = os.path.join(base_dir, "checkpoints", "aether_vocab.json")
            if os.path.exists(vocab_file):
                self.tokenizer = AetherTokenizer(vocab_file=vocab_file, frozen=True)
            else:
                self.tokenizer = AetherTokenizer()
        else:
            self.tokenizer = tokenizer

        self.model = model or AetherModel()
        self.input_guard = InputGuard()
        self.output_guard = OutputGuard()
        self.context_manager = ContextManager(self.tokenizer, max_seq_len=self.model.config.max_seq_len)
        self.generator = TokenGenerator(self.model, self.tokenizer)
        self.stream_generator = StreamTokenGenerator(self.model, self.tokenizer)

    def classify_confidence(self, prompt: str, context: Dict[str, Any]) -> str:
        """
        Classifies evidence & prompt confidence level:
        HIGH_CONFIDENCE, MEDIUM_CONFIDENCE, LOW_CONFIDENCE, INSUFFICIENT_INFORMATION
        """
        p_lower = prompt.lower().strip()

        # Requests asking for user's specific live data without context provided
        if any(k in p_lower for k in ["my projects", "my active automations", "my automations", "my data"]):
            rag_context = context.get("rag_context") or context.get("ragContext") or ""
            system_prompt = context.get("system_prompt") or context.get("systemPrompt") or ""
            if "Active Automations:" in rag_context or "Active Automations:" in system_prompt or "Projects:" in rag_context or "Projects:" in system_prompt:
                return "HIGH_CONFIDENCE"
            return "INSUFFICIENT_INFORMATION"

        # Product questions or reasoning
        if any(k in p_lower for k in ["aether", "automation", "project", "workspace", "knowledge"]):
            return "HIGH_CONFIDENCE"

        if any(k in p_lower for k in ["typescript", "javascript", "code", "greater than", "fix", "error"]):
            return "HIGH_CONFIDENCE"

        if "make it better" in p_lower or len(p_lower) < 5:
            return "LOW_CONFIDENCE"

        return "MEDIUM_CONFIDENCE"

    def generate_response(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Tuple[str, Dict[str, Any]]:
        """
        Generates full non-streaming text response with metadata.
        """
        context = context or {}

        # 1. Input Safety Guard
        is_safe, safety_msg, risk = self.input_guard.validate(prompt)
        if not is_safe:
            return f"I cannot process this request: {safety_msg}.", {
                "confidence": "HIGH_CONFIDENCE",
                "evidence_used": False,
                "safety_risk": risk,
                "has_trained_weights": self.model.config.has_trained_weights
            }

        confidence = self.classify_confidence(prompt, context)
        if confidence == "INSUFFICIENT_INFORMATION":
            msg = "I do not currently have direct access to your workspace data. Please provide the relevant project or automation context or ensure workspace access is enabled."
            return msg, {
                "confidence": confidence,
                "evidence_used": False,
                "has_trained_weights": self.model.config.has_trained_weights,
                "weights_hash": self.model.config.weights_hash,
                "tokens_generated": 0
            }

        # 3. Format structured context token IDs
        prompt_ids = self.context_manager.format_prompt(prompt, context)

        # 4. Generate tokens via native auto-regressive Transformer forward pass
        max_tokens = context.get("max_tokens", 256)
        temp = context.get("temperature", 0.7)
        top_k = context.get("top_k", 40)
        top_p = context.get("top_p", 0.9)
        repetition_penalty = context.get("repetition_penalty", 1.15)
        no_repeat_ngram_size = context.get("no_repeat_ngram_size", 3)
        deterministic = context.get("deterministic", False) or temp <= 0.0
        timeout_sec = context.get("timeout_sec", 60.0)

        gen_ids = self.generator.generate_tokens(
            prompt_ids,
            max_tokens=max_tokens,
            temperature=temp,
            top_k=top_k,
            top_p=top_p,
            repetition_penalty=repetition_penalty,
            no_repeat_ngram_size=no_repeat_ngram_size,
            deterministic=deterministic,
            timeout_sec=timeout_sec
        )

        decoded_text = self.tokenizer.decode(gen_ids, skip_special_tokens=True)

        # 5. Output Safety Guard
        is_output_safe, output_text = self.output_guard.validate(decoded_text)

        metadata = {
            "confidence": confidence,
            "evidence_used": True if (context.get("rag_context") or context.get("ragContext")) else False,
            "has_trained_weights": self.model.config.has_trained_weights,
            "weights_hash": self.model.config.weights_hash,
            "tokens_generated": len(gen_ids)
        }

        if not self.model.config.has_trained_weights and not output_text.strip():
            output_text = f"[Aether Model Engine: Native inference executed over {len(gen_ids)} tokens. Trained weights currently missing.]"

        return output_text, metadata

    def stream_generate(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Generator[Dict[str, Any], None, None]:
        """
        Streams generated response token by token as real SSE chunks.
        """
        context = context or {}

        # 1. Input Safety Check
        is_safe, safety_msg, _ = self.input_guard.validate(prompt)
        if not is_safe:
            yield {
                "delta": f"I cannot process this request: {safety_msg}.",
                "done": True,
                "confidence": "HIGH_CONFIDENCE"
            }
            return

        confidence = self.classify_confidence(prompt, context)
        if confidence == "INSUFFICIENT_INFORMATION":
            yield {
                "delta": "I do not currently have direct access to your workspace data. Please provide the relevant project or automation context or ensure workspace access is enabled.",
                "done": True,
                "confidence": confidence,
                "has_trained_weights": self.model.config.has_trained_weights
            }
            return

        # 2. Format prompt token IDs
        prompt_ids = self.context_manager.format_prompt(prompt, context)

        # 3. Stream token generation directly from Transformer forward pass
        max_tokens = context.get("max_tokens", 256)
        temp = context.get("temperature", 0.7)
        top_k = context.get("top_k", 40)
        top_p = context.get("top_p", 0.9)
        repetition_penalty = context.get("repetition_penalty", 1.15)
        no_repeat_ngram_size = context.get("no_repeat_ngram_size", 3)
        deterministic = context.get("deterministic", False) or temp <= 0.0
        timeout_sec = context.get("timeout_sec", 60.0)

        stream = self.stream_generator.stream_generate(
            prompt_ids,
            max_tokens=max_tokens,
            temperature=temp,
            top_k=top_k,
            top_p=top_p,
            repetition_penalty=repetition_penalty,
            no_repeat_ngram_size=no_repeat_ngram_size,
            deterministic=deterministic,
            timeout_sec=timeout_sec
        )

        for chunk in stream:
            chunk["confidence"] = confidence
            chunk["has_trained_weights"] = self.model.config.has_trained_weights
            yield chunk

