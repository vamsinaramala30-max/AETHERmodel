"""
AETHER MODEL — Model Configuration
Defines hyperparameters, context windows, and execution settings for the Aether Transformer architecture.
"""

from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class ModelConfig:
    vocab_size: int = 4096
    d_model: int = 256
    n_layers: int = 4
    n_heads: int = 4
    d_ff: int = 512
    max_seq_len: int = 512
    dropout: float = 0.1
    epsilon: float = 1e-5
    device: str = "cpu"
    precision: str = "float32"
    weights_path: Optional[str] = None
    weights_hash: str = "missing_weights_sha256"
    has_trained_weights: bool = False
    stop_tokens: List[str] = field(default_factory=lambda: ["<eos>", "<pad>"])

    def to_dict(self) -> dict:
        return {
            "vocab_size": self.vocab_size,
            "d_model": self.d_model,
            "n_layers": self.n_layers,
            "n_heads": self.n_heads,
            "d_ff": self.d_ff,
            "max_seq_len": self.max_seq_len,
            "dropout": self.dropout,
            "device": self.device,
            "precision": self.precision,
            "has_trained_weights": self.has_trained_weights,
            "weights_hash": self.weights_hash,
        }
