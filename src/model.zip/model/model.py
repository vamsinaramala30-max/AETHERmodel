"""
AETHER MODEL — High-level AetherModel Facade
Provides initialization, state dict management, robust checkpoint save/load with checksums,
and full forward/backward training pass execution.
"""

import os
import json
import hashlib
import time
from typing import List, Dict, Any, Optional, Tuple
from model.config.model_config import ModelConfig
from model.architecture.transformer import AetherTransformerArchitecture

class AetherModel:
    def __init__(self, config: Optional[ModelConfig] = None, skip_checkpoint: bool = False):
        self.config = config or ModelConfig()
        self.architecture = AetherTransformerArchitecture(self.config)
        self.metadata: Dict[str, Any] = {}
        self.load_status: str = "STARTING"
        if not skip_checkpoint:
            self._check_and_load_default_checkpoint()
        else:
            self.config.has_trained_weights = False
            self.load_status = "READY"

    def _check_and_load_default_checkpoint(self) -> None:
        """Inspects disk for trained weights checkpoint and loads if valid."""
        # 1. Check explicit weights_path
        if self.config.weights_path:
            if os.path.exists(self.config.weights_path):
                self.load_checkpoint(self.config.weights_path)
                return
            else:
                self.config.has_trained_weights = False
                self.config.weights_hash = "missing_weights_sha256"
                self.load_status = "CHECKPOINT_MISSING"
                return

        # 2. Check default checkpoints directory
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        default_ckpt = os.path.join(base_dir, "checkpoints", "aether_checkpoint_v1.json")
        if os.path.exists(default_ckpt):
            self.load_checkpoint(default_ckpt)
        else:
            self.config.has_trained_weights = False
            self.config.weights_hash = "missing_weights_sha256"
            self.load_status = "CHECKPOINT_MISSING"

    def forward(self, input_ids: List[int]) -> List[float]:
        """Calculates next-token candidate logits."""
        return self.architecture.forward(input_ids)

    def forward_step(
        self,
        token_id: int,
        start_pos: int,
        layer_caches: Optional[List[Tuple[Any, Any]]] = None
    ) -> Tuple[Any, List[Tuple[Any, Any]]]:
        """Calculates next-token logits for single token position using internal KV-caching."""
        return self.architecture.forward_step(token_id, start_pos=start_pos, layer_caches=layer_caches)

    def forward_prompt(
        self,
        prompt_token_ids: List[int]
    ) -> Tuple[Any, List[Tuple[Any, Any]]]:
        """Calculates next-token logits and initializes KV-caching for full prompt sequence in parallel."""
        return self.architecture.forward_prompt(prompt_token_ids)

    def forward_all(self, input_ids: List[int]) -> List[List[float]]:
        """Calculates logits for every position in sequence [seq_len, vocab_size]."""
        return self.architecture.forward_all(input_ids)


    def backward(self, grad_logits: List[List[float]]) -> None:
        """Runs full analytical backpropagation pass."""
        self.architecture.backward(grad_logits)

    def zero_grad(self) -> None:
        self.architecture.zero_grad()

    def get_state_dict(self) -> Dict[str, Any]:
        return self.architecture.get_state_dict()

    def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
        self.architecture.load_state_dict(state_dict)

    def save_checkpoint(self, checkpoint_path: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Saves full parameter state dict and validated metadata to JSON checkpoint with SHA256 checksum.
        """
        os.makedirs(os.path.dirname(os.path.abspath(checkpoint_path)), exist_ok=True)
        meta = {
            "checkpoint_version": "1.0.0",
            "model_name": "aether-v1-authoritative",
            "version": "1.0.0",
            "model_version": "1.0.0",
            "tokenizer_version": "1.0.0",
            "architecture_version": "transformer_decoder_v1",
            "architecture_hash": "transformer_decoder_v1",
            "vocabulary_size": self.config.vocab_size,
            "vocab_size": self.config.vocab_size,
            "vocabulary_hash": "aether_vocab_v1",
            "d_model": self.config.d_model,
            "n_layers": self.config.n_layers,
            "n_heads": self.config.n_heads,
            "d_ff": self.config.d_ff,
            "max_seq_len": self.config.max_seq_len,
            "created_at": int(time.time() * 1000),
            "creation_timestamp": int(time.time() * 1000),
            "quality_classification": "PRODUCTION_CANDIDATE",
        }
        if metadata:
            meta.update(metadata)

        state_dict = self.get_state_dict()
        data_str = json.dumps(state_dict, sort_keys=True, separators=(',', ':'))
        checksum = hashlib.sha256(data_str.encode("utf-8")).hexdigest()
        meta["checksum"] = checksum
        meta["checkpoint_sha256"] = checksum
        meta["weights_hash"] = f"sha256_{checksum[:16]}"

        checkpoint_payload = {
            "metadata": meta,
            "state_dict": state_dict,
        }

        with open(checkpoint_path, "w", encoding="utf-8") as f:
            json.dump(checkpoint_payload, f)

        self.config.weights_path = checkpoint_path
        self.config.has_trained_weights = True
        self.config.weights_hash = meta["weights_hash"]
        self.metadata = meta
        self.load_status = "READY"
        return checksum

    def load_checkpoint(self, checkpoint_path: str) -> bool:
        """
        Loads and validates checkpoint file against strict integrity standards:
        1. Existence check
        2. JSON validity & structure check
        3. Checksum SHA-256 verification
        4. Tensor dimensions & architecture compatibility
        5. Vocabulary & configuration alignment
        """
        if not os.path.exists(checkpoint_path):
            self.config.has_trained_weights = False
            self.config.weights_hash = "missing_weights_sha256"
            self.load_status = "CHECKPOINT_MISSING"
            return False

        try:
            with open(checkpoint_path, "r", encoding="utf-8") as f:
                payload = json.load(f)

            if not isinstance(payload, dict):
                self.config.has_trained_weights = False
                self.config.weights_hash = "corrupted_weights_sha256"
                self.load_status = "CHECKPOINT_CORRUPTED"
                return False

            meta = payload.get("metadata", {})
            state_dict = payload.get("state_dict", {})

            if not isinstance(state_dict, dict) or "token_embedding" not in state_dict:
                self.config.has_trained_weights = False
                self.config.weights_hash = "corrupted_weights_sha256"
                self.load_status = "CHECKPOINT_CORRUPTED"
                return False

            # Checksum verification if metadata checksum is present
            expected_checksum = meta.get("checksum") or meta.get("checkpoint_sha256")
            if expected_checksum:
                data_str = json.dumps(state_dict, sort_keys=True, separators=(',', ':'))
                actual_checksum = hashlib.sha256(data_str.encode("utf-8")).hexdigest()
                if actual_checksum != expected_checksum:
                    self.config.has_trained_weights = False
                    self.config.weights_hash = "corrupted_weights_sha256"
                    self.load_status = "CHECKPOINT_CORRUPTED"
                    return False

            # Architecture compatibility check
            new_d_model = meta.get("d_model", self.config.d_model)
            new_n_layers = meta.get("n_layers", self.config.n_layers)
            new_n_heads = meta.get("n_heads", self.config.n_heads)
            new_d_ff = meta.get("d_ff", new_d_model * 2)
            new_vocab_size = meta.get("vocab_size", meta.get("vocabulary_size", self.config.vocab_size))

            if new_d_model <= 0 or new_n_layers <= 0 or new_n_heads <= 0 or new_vocab_size <= 0:
                self.config.has_trained_weights = False
                self.config.weights_hash = "incompatible_architecture"
                self.load_status = "ARCHITECTURE_MISMATCH"
                return False

            # Verify tensor dimension alignment against state_dict
            emb_weight = state_dict.get("token_embedding", {}).get("weight", [])
            if emb_weight:
                emb_rows = len(emb_weight)
                emb_cols = len(emb_weight[0]) if emb_rows > 0 else 0
                if emb_cols != new_d_model or emb_rows != new_vocab_size:
                    self.config.has_trained_weights = False
                    self.config.weights_hash = "incompatible_weights_dimension"
                    self.load_status = "ARCHITECTURE_MISMATCH"
                    return False

            needs_rebuild = (
                self.config.d_model != new_d_model or
                self.config.n_layers != new_n_layers or
                self.config.n_heads != new_n_heads or
                self.config.d_ff != new_d_ff or
                self.config.vocab_size != new_vocab_size
            )
            self.config.d_model = new_d_model
            self.config.n_layers = new_n_layers
            self.config.n_heads = new_n_heads
            self.config.d_ff = new_d_ff
            self.config.vocab_size = new_vocab_size

            if needs_rebuild or self.architecture is None:
                self.architecture = AetherTransformerArchitecture(self.config)

            # Restore state dict
            self.load_state_dict(state_dict)
            self.config.weights_path = checkpoint_path
            self.config.has_trained_weights = True
            self.config.weights_hash = meta.get("weights_hash", f"sha256_{os.path.basename(checkpoint_path)}")
            self.metadata = meta
            self.load_status = "READY"
            return True
        except Exception:
            self.config.has_trained_weights = False
            self.config.weights_hash = "load_failed_sha256"
            self.load_status = "MODEL_LOAD_FAILED"
            return False

    def load_weights(self, weights_path: str) -> bool:
        return self.load_checkpoint(weights_path)

    def get_info(self) -> Dict[str, Any]:
        return {
            "name": "aether-v1-authoritative",
            "vocab_size": self.config.vocab_size,
            "d_model": self.config.d_model,
            "n_layers": self.config.n_layers,
            "n_heads": self.config.n_heads,
            "has_trained_weights": self.config.has_trained_weights,
            "weights_hash": self.config.weights_hash,
            "status": self.load_status,
            "metadata": self.metadata,
        }

    @property
    def vocab_size(self) -> int:
        return self.config.vocab_size

