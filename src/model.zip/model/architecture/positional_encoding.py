"""
AETHER MODEL — Positional Encoding
Adds sinusoidal positional information to token embeddings for sequence-order awareness.
"""

import math
import numpy as np
from typing import Union, List

class SinusoidalPositionalEncoding:
    def __init__(self, d_model: int, max_seq_len: int = 1024):
        self.d_model = d_model
        self.max_seq_len = max_seq_len
        pos_arr = np.arange(max_seq_len, dtype=np.float64)[:, None]
        i_arr = np.arange(d_model, dtype=np.float64)[None, :]
        even_mask = (i_arr % 2 == 0)
        denom_pow = np.where(even_mask, i_arr, i_arr - 1) / d_model
        angles = pos_arr / (10000.0 ** denom_pow)
        self.pe: np.ndarray = np.where(even_mask, np.sin(angles), np.cos(angles))


    def forward(self, x: Union[np.ndarray, List[List[float]]], start_pos: int = 0) -> np.ndarray:
        """
        Add positional encodings element-wise to input vector sequence starting at start_pos.
        """
        x_arr = np.asarray(x, dtype=np.float64)
        if x_arr.size == 0:
            return x_arr
        seq_len = x_arr.shape[0]
        end_pos = start_pos + seq_len
        if end_pos <= self.max_seq_len:
            pe_slice = self.pe[start_pos:end_pos]
        else:
            indices = [min(start_pos + i, self.max_seq_len - 1) for i in range(seq_len)]
            pe_slice = self.pe[indices]
        return x_arr + pe_slice

