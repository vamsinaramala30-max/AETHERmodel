"""
AETHER MODEL — Token Embeddings
Maps discrete token IDs into d_model dimensional dense vector space representations.
Supports forward lookup, parameter management, and analytical gradient accumulation.
"""

import math
import numpy as np
from typing import List, Dict, Any, Optional, Union

class TokenEmbedding:
    def __init__(self, vocab_size: int, d_model: int):
        self.vocab_size = vocab_size
        self.d_model = d_model
        bound = 1.0 / math.sqrt(d_model)
        # Xavier uniform initialization
        i_arr = np.arange(vocab_size, dtype=np.float64)[:, None]
        j_arr = np.arange(d_model, dtype=np.float64)[None, :]
        self.weight: np.ndarray = (((i_arr * 31 + j_arr * 17 + 7) % 1000) / 1000.0 - 0.5) * 2.0 * bound
        self.grad_weight: np.ndarray = np.zeros((vocab_size, d_model), dtype=np.float64)
        self._last_input_ids: Optional[List[int]] = None


    UNK_TOKEN_ID: int = 1  # <unk> token ID — must match tokenizer.py

    def forward(self, input_ids: Union[List[int], np.ndarray]) -> np.ndarray:
        if isinstance(input_ids, list):
            self._last_input_ids = list(input_ids)
            if not input_ids:
                return np.zeros((0, self.d_model), dtype=np.float64)
            input_arr = np.asarray(input_ids, dtype=np.int64)
        else:
            self._last_input_ids = input_ids.tolist()
            if input_ids.size == 0:
                return np.zeros((0, self.d_model), dtype=np.float64)
            input_arr = input_ids

        # Clamp out-of-range IDs to UNK — never silently alias via modulo
        if self.vocab_size > 0:
            out_of_range = (input_arr < 0) | (input_arr >= self.vocab_size)
            indices = np.where(out_of_range, self.UNK_TOKEN_ID, input_arr)
        else:
            indices = np.zeros_like(input_arr)
        return self.weight[indices]

    def backward(self, grad_output: Union[np.ndarray, List[List[float]]]) -> None:
        """
        Accumulate gradients into grad_weight for corresponding token IDs.
        grad_output shape: [seq_len, d_model]
        """
        if self._last_input_ids is None:
            return
        g_out = np.asarray(grad_output, dtype=np.float64)
        for pos, token_id in enumerate(self._last_input_ids):
            if self.vocab_size > 0 and 0 <= token_id < self.vocab_size:
                self.grad_weight[token_id] += g_out[pos]
            else:
                # Out-of-range token — accumulate gradient to UNK embedding
                self.grad_weight[self.UNK_TOKEN_ID] += g_out[pos]

    def zero_grad(self) -> None:
        self.grad_weight.fill(0.0)

    def get_parameters(self) -> Dict[str, Any]:
        return {"weight": self.weight.tolist()}

    def set_parameters(self, params: Dict[str, Any]) -> None:
        if "weight" in params:
            self.weight = np.array(params["weight"], dtype=np.float64)
            self.vocab_size = self.weight.shape[0]
            self.d_model = self.weight.shape[1] if self.vocab_size > 0 else self.d_model
            self.grad_weight = np.zeros((self.vocab_size, self.d_model), dtype=np.float64)

