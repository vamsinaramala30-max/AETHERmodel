"""
AETHER MODEL — Layer Normalization
Standard LayerNorm over hidden dimensions with learnable scale (gamma) and shift (beta).
Supports forward normalization, caching, analytical backpropagation, and parameter state dict.
"""

import math
import numpy as np
from typing import List, Dict, Any, Optional, Tuple, Union

class LayerNorm:
    def __init__(self, d_model: int, eps: float = 1e-5):
        self.d_model = d_model
        self.eps = eps
        self.gamma: np.ndarray = np.ones(d_model, dtype=np.float64)
        self.beta: np.ndarray = np.zeros(d_model, dtype=np.float64)

        self.grad_gamma: np.ndarray = np.zeros(d_model, dtype=np.float64)
        self.grad_beta: np.ndarray = np.zeros(d_model, dtype=np.float64)

        self._cache: Optional[Tuple[np.ndarray, np.ndarray, np.ndarray]] = None # (x_hat, mean, std)

    def forward(self, x: Union[np.ndarray, List[List[float]]]) -> np.ndarray:
        x_arr = np.asarray(x, dtype=np.float64)
        if x_arr.size == 0:
            return x_arr
        mean = np.mean(x_arr, axis=-1, keepdims=True)
        var = np.var(x_arr, axis=-1, keepdims=True)
        std = np.sqrt(var + self.eps)
        x_hat = (x_arr - mean) / std
        output = self.gamma * x_hat + self.beta
        self._cache = (x_hat, mean, std)
        return output

    def backward(self, grad_output: Union[np.ndarray, List[List[float]]]) -> np.ndarray:
        """
        Analytical LayerNorm backward pass.
        grad_output: [seq_len, d_model]
        Returns grad_input: [seq_len, d_model]
        """
        if self._cache is None:
            g_out = np.asarray(grad_output, dtype=np.float64)
            return np.zeros_like(g_out)

        x_hat, mean, std = self._cache
        g_out = np.asarray(grad_output, dtype=np.float64)
        D = float(self.d_model)

        self.grad_gamma += np.sum(g_out * x_hat, axis=0)
        self.grad_beta += np.sum(g_out, axis=0)

        sum_gout_gamma = np.sum(g_out * self.gamma, axis=-1, keepdims=True)
        sum_gout_gamma_xhat = np.sum(g_out * self.gamma * x_hat, axis=-1, keepdims=True)

        grad_input = (self.gamma * g_out - (sum_gout_gamma / D) - (x_hat * sum_gout_gamma_xhat / D)) / std
        return grad_input

    def zero_grad(self) -> None:
        self.grad_gamma.fill(0.0)
        self.grad_beta.fill(0.0)

    def get_parameters(self) -> Dict[str, Any]:
        return {
            "gamma": self.gamma.tolist(),
            "beta": self.beta.tolist()
        }

    def set_parameters(self, params: Dict[str, Any]) -> None:
        if "gamma" in params:
            self.gamma = np.array(params["gamma"], dtype=np.float64)
            self.d_model = self.gamma.shape[0]
            self.grad_gamma = np.zeros(self.d_model, dtype=np.float64)
        if "beta" in params:
            self.beta = np.array(params["beta"], dtype=np.float64)
            self.grad_beta = np.zeros(self.d_model, dtype=np.float64)

