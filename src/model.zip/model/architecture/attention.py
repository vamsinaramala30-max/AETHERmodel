"""
AETHER MODEL — Multi-Head Self-Attention
Computes scaled dot-product self-attention across n_heads with causal sequence masking.
Supports forward pass, caching, exact analytical backpropagation, and state dict serialization.
"""

import math
import numpy as np
from typing import List, Dict, Any, Optional, Tuple, Union

class MultiHeadAttention:
    def __init__(self, d_model: int, n_heads: int):
        assert d_model % n_heads == 0, "d_model must be divisible by n_heads"
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_k = d_model // n_heads

        scale = 1.0 / math.sqrt(d_model)
        i_m = np.arange(d_model, dtype=np.float64)[:, None]
        j_m = np.arange(d_model, dtype=np.float64)[None, :]

        self.q_proj: np.ndarray = (((i_m * 13 + j_m * 7) % 100) / 100.0 - 0.5) * scale
        self.k_proj: np.ndarray = (((i_m * 17 + j_m * 11) % 100) / 100.0 - 0.5) * scale
        self.v_proj: np.ndarray = (((i_m * 19 + j_m * 23) % 100) / 100.0 - 0.5) * scale
        self.out_proj: np.ndarray = (((i_m * 29 + j_m * 31) % 100) / 100.0 - 0.5) * scale


        self.grad_q_proj: np.ndarray = np.zeros((d_model, d_model), dtype=np.float64)
        self.grad_k_proj: np.ndarray = np.zeros((d_model, d_model), dtype=np.float64)
        self.grad_v_proj: np.ndarray = np.zeros((d_model, d_model), dtype=np.float64)
        self.grad_out_proj: np.ndarray = np.zeros((d_model, d_model), dtype=np.float64)

        self._cache: Optional[Dict[str, Any]] = None

    def forward(
        self,
        x: Union[np.ndarray, List[List[float]]],
        kv_cache: Optional[Tuple[np.ndarray, np.ndarray]] = None,
        use_kv_cache: bool = False
    ) -> Union[np.ndarray, Tuple[np.ndarray, Tuple[np.ndarray, np.ndarray]]]:
        x_arr = np.asarray(x, dtype=np.float64)
        seq_len = x_arr.shape[0]
        if seq_len == 0:
            empty_cache = (np.zeros((0, self.d_model), dtype=np.float64), np.zeros((0, self.d_model), dtype=np.float64))
            if use_kv_cache or kv_cache is not None:
                return np.zeros((0, self.d_model), dtype=np.float64), empty_cache
            return np.zeros((0, self.d_model), dtype=np.float64)

        queries = x_arr @ self.q_proj
        keys_new = x_arr @ self.k_proj
        values_new = x_arr @ self.v_proj

        if kv_cache is not None:
            cached_k, cached_v = kv_cache
            keys = np.vstack([cached_k, keys_new]) if cached_k.size > 0 else keys_new
            values = np.vstack([cached_v, values_new]) if cached_v.size > 0 else values_new
            new_kv_cache = (keys, values)
        else:
            keys = keys_new
            values = values_new
            new_kv_cache = (keys, values)

        total_seq_len = keys.shape[0]
        scale = 1.0 / math.sqrt(self.d_k)

        offset = total_seq_len - seq_len
        dots = (queries @ keys.T) * scale

        if seq_len == 1 and total_seq_len == 1:
            max_score = np.max(dots)
            exps = np.exp(dots - max_score)
            sum_exps = np.sum(exps)
            if sum_exps == 0:
                sum_exps = 1e-9
            attn_weights = exps / sum_exps
            context_vecs = attn_weights @ values
        elif seq_len == 1:
            # Single token with KV cache: all total_seq_len keys are valid (j <= offset)
            max_score = np.max(dots, axis=-1, keepdims=True)
            exps = np.exp(dots - max_score)
            sum_exps = np.sum(exps, axis=-1, keepdims=True)
            sum_exps = np.where(sum_exps == 0.0, 1e-9, sum_exps)
            attn_weights = exps / sum_exps
            context_vecs = attn_weights @ values
        else:
            # Multi-token sequence with lower-triangular causal mask
            mask = np.tril(np.ones((seq_len, total_seq_len), dtype=bool), k=offset)
            dots = np.where(mask, dots, -1e9)
            max_scores = np.max(dots, axis=-1, keepdims=True)
            exps = np.exp(dots - max_scores)
            exps = np.where(mask, exps, 0.0)
            sum_exps = np.sum(exps, axis=-1, keepdims=True)
            sum_exps = np.where(sum_exps == 0.0, 1e-9, sum_exps)
            attn_weights = exps / sum_exps
            context_vecs = attn_weights @ values

        attn_out = context_vecs @ self.out_proj

        self._cache = {
            "x": x_arr,
            "queries": queries,
            "keys": keys,
            "values": values,
            "attn_weights": attn_weights,
            "context_vecs": context_vecs,
            "scale": scale,
        }

        if use_kv_cache or kv_cache is not None:
            return attn_out, new_kv_cache
        return attn_out


    def backward(self, grad_output: Union[np.ndarray, List[List[float]]]) -> np.ndarray:
        """
        Analytical causal self-attention backward pass.
        grad_output: [seq_len, d_model]
        Returns grad_input: [seq_len, d_model]
        """
        if self._cache is None:
            g_out = np.asarray(grad_output, dtype=np.float64)
            return np.zeros_like(g_out)

        x = self._cache["x"]
        queries = self._cache["queries"]
        keys = self._cache["keys"]
        values = self._cache["values"]
        attn_weights = self._cache["attn_weights"]
        context_vecs = self._cache["context_vecs"]
        scale = self._cache["scale"]

        g_out = np.asarray(grad_output, dtype=np.float64)
        seq_len = x.shape[0]

        # 1. Gradients w.r.t out_proj and context_vecs
        self.grad_out_proj += context_vecs.T @ g_out
        grad_context = g_out @ self.out_proj.T

        # 2. Backprop from context to values and attention weights
        grad_values = np.zeros((seq_len, self.d_model), dtype=np.float64)
        grad_queries = np.zeros((seq_len, self.d_model), dtype=np.float64)
        grad_keys = np.zeros((seq_len, self.d_model), dtype=np.float64)

        for i in range(seq_len):
            g_ctx = grad_context[i]
            w_row = attn_weights[i, :i + 1]

            grad_v_slice = np.outer(w_row, g_ctx)
            grad_values[:i + 1] += grad_v_slice

            grad_w_row = values[:i + 1] @ g_ctx

            sum_w_gradw = np.sum(w_row * grad_w_row)
            grad_scores = w_row * (grad_w_row - sum_w_gradw)

            g_s = grad_scores * scale
            grad_queries[i] += g_s @ keys[:i + 1]
            grad_keys[:i + 1] += np.outer(g_s, queries[i])

        # 3. Gradients w.r.t Q, K, V projection matrices and input x
        self.grad_q_proj += x.T @ grad_queries
        self.grad_k_proj += x.T @ grad_keys
        self.grad_v_proj += x.T @ grad_values

        grad_x = grad_queries @ self.q_proj.T + grad_keys @ self.k_proj.T + grad_values @ self.v_proj.T
        return grad_x

    def zero_grad(self) -> None:
        self.grad_q_proj.fill(0.0)
        self.grad_k_proj.fill(0.0)
        self.grad_v_proj.fill(0.0)
        self.grad_out_proj.fill(0.0)

    def get_parameters(self) -> Dict[str, Any]:
        return {
            "q_proj": self.q_proj.tolist(),
            "k_proj": self.k_proj.tolist(),
            "v_proj": self.v_proj.tolist(),
            "out_proj": self.out_proj.tolist(),
        }

    def set_parameters(self, params: Dict[str, Any]) -> None:
        if "q_proj" in params:
            self.q_proj = np.array(params["q_proj"], dtype=np.float64)
        if "k_proj" in params:
            self.k_proj = np.array(params["k_proj"], dtype=np.float64)
        if "v_proj" in params:
            self.v_proj = np.array(params["v_proj"], dtype=np.float64)
        if "out_proj" in params:
            self.out_proj = np.array(params["out_proj"], dtype=np.float64)
        self.zero_grad()

