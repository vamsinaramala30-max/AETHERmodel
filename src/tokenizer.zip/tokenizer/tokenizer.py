"""
AETHER MODEL — Authoritative Tokenizer Engine

Responsibilities:
- Deterministic text -> token ID encoding
- Deterministic token ID -> text decoding
- Vocabulary persistence
- Vocabulary freezing for evaluation/inference
- Special-token management
- Vocabulary integrity validation
- Checkpoint vocabulary compatibility validation

IMPORTANT:
The tokenizer vocabulary is part of the model contract.

Training:
    tokenizer may be unfrozen while building the vocabulary.

Evaluation / Inference:
    tokenizer MUST be frozen.

The tokenizer must NEVER silently change vocabulary IDs during inference.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
from typing import Any, Dict, Iterable, List, Optional


# ============================================================================
# SPECIAL TOKENS
# ============================================================================

SPECIAL_TOKENS: List[str] = [
    "<pad>",
    "<unk>",
    "<eos>",
    "<system>",
    "<user>",
    "<assistant>",
    "<tool>",
    "<evidence>",
]


PAD_TOKEN_ID = 0
UNK_TOKEN_ID = 1
EOS_TOKEN_ID = 2
SYSTEM_TOKEN_ID = 3
USER_TOKEN_ID = 4
ASSISTANT_TOKEN_ID = 5
TOOL_TOKEN_ID = 6
EVIDENCE_TOKEN_ID = 7

SPECIAL_TOKEN_IDS: Dict[str, int] = {
    "<pad>": PAD_TOKEN_ID,
    "<unk>": UNK_TOKEN_ID,
    "<eos>": EOS_TOKEN_ID,
    "<system>": SYSTEM_TOKEN_ID,
    "<user>": USER_TOKEN_ID,
    "<assistant>": ASSISTANT_TOKEN_ID,
    "<tool>": TOOL_TOKEN_ID,
    "<evidence>": EVIDENCE_TOKEN_ID,
}


# ============================================================================
# TOKENIZER
# ============================================================================


class AetherTokenizer:
    """
    Deterministic tokenizer used by AETHER_MODEL.

    Modes:

        Training:
            AetherTokenizer(frozen=False)

        Evaluation:
            AetherTokenizer(vocab_file="...", frozen=True)

        Inference:
            AetherTokenizer(vocab_file="...", frozen=True)

    Unknown tokens in frozen mode are mapped to <unk>.
    """

    VERSION = "2.0.0"

    # Special tokens must be matched before ordinary tokens.
    _TOKEN_PATTERN = re.compile(
        r"""
        (
            <pad>
            |<unk>
            |<eos>
            |<system>
            |<user>
            |<assistant>
            |<tool>
            |<evidence>

            |[A-Za-z0-9_]+

            |[^\w\s]
        )
        """,
        re.VERBOSE,
    )

    _NO_SPACE_BEFORE = {
        ".",
        ",",
        "!",
        "?",
        ":",
        ";",
        "%",
        ")",
        "]",
        "}",
        "'",
        '"',
    }

    _NO_SPACE_AFTER = {
        "(",
        "[",
        "{",
    }

    def __init__(
        self,
        vocab_file: Optional[str] = None,
        frozen: bool = False,
        *,
        allow_default_vocab: bool = True,
    ) -> None:

        self.special_tokens: List[str] = list(SPECIAL_TOKENS)

        self.token_to_id: Dict[str, int] = {}
        self.id_to_token: Dict[int, str] = {}

        self.frozen: bool = bool(frozen)

        # Initialize special tokens first.
        self._initialize_special_tokens()

        # Training-only foundational vocabulary.
        #
        # IMPORTANT:
        # This vocabulary is NOT used to override an authoritative
        # vocabulary loaded from a checkpoint.
        if allow_default_vocab and vocab_file is None:
            self._initialize_default_vocabulary()

        # If a vocabulary file is supplied, it becomes authoritative.
        if vocab_file is not None:
            self.load_vocab(vocab_file)

            # A loaded vocabulary should normally be frozen for
            # evaluation/inference.
            if frozen:
                self.freeze()

    # ========================================================================
    # INITIALIZATION
    # ========================================================================

    def _initialize_special_tokens(self) -> None:
        """Initialize and validate all reserved special-token IDs."""

        self.token_to_id.clear()
        self.id_to_token.clear()

        for token, token_id in SPECIAL_TOKEN_IDS.items():
            self.token_to_id[token] = token_id
            self.id_to_token[token_id] = token

        self.next_id = len(SPECIAL_TOKEN_IDS)

    def _initialize_default_vocabulary(self) -> None:
        """
        Create the foundational training vocabulary.

        This is intended for vocabulary construction/training only.

        Once the final vocabulary is saved and used for inference,
        the vocabulary should be loaded from that saved file and frozen.
        """

        common_vocab = [
            # ----------------------------------------------------------------
            # Basic English
            # ----------------------------------------------------------------
            "the",
            "be",
            "to",
            "of",
            "and",
            "a",
            "in",
            "that",
            "have",
            "i",
            "it",
            "for",
            "not",
            "on",
            "with",
            "he",
            "as",
            "you",
            "do",
            "at",
            "this",
            "but",
            "his",
            "by",
            "from",
            "they",
            "we",
            "say",
            "her",
            "she",
            "or",
            "an",
            "will",
            "my",
            "one",
            "all",
            "would",
            "there",
            "their",
            "what",
            "so",
            "up",
            "out",
            "if",
            "about",
            "who",
            "get",
            "which",
            "go",
            "me",
            "when",
            "make",
            "can",
            "like",
            "time",
            "no",
            "just",
            "him",
            "know",
            "take",
            "people",
            "into",
            "year",
            "your",
            "good",
            "some",
            "could",
            "them",
            "see",
            "other",
            "than",
            "then",
            "now",
            "look",
            "only",
            "come",
            "its",
            "over",
            "think",
            "also",
            "back",
            "after",
            "use",
            "two",
            "how",
            "our",
            "work",
            "first",
            "well",
            "way",
            "even",
            "new",
            "want",
            "because",
            "any",
            "these",
            "give",
            "day",
            "most",
            "us",
            "is",
            "are",
            "was",
            "were",
            "been",
            "has",
            "had",
            "does",
            "did",
            "am",
            "hello",
            "hi",
            "hey",
            "please",
            "thank",
            "thanks",
            "welcome",
            "yes",
            "help",
            "here",
            "where",
            "why",
            "should",
            "must",
            "might",
            "shall",

            # ----------------------------------------------------------------
            # Numbers / reasoning
            # ----------------------------------------------------------------
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "first",
            "second",
            "third",
            "step",
            "greater",
            "less",
            "equal",
            "true",
            "false",
            "null",
            "undefined",
            "transitive",
            "property",
            "strictly",
            "conclude",
            "logical",
            "deductive",
            "syllogism",
            "follows",
            "conclusion",
            "premise",
            "since",

            # ----------------------------------------------------------------
            # Punctuation / symbols
            # ----------------------------------------------------------------
            ".",
            ",",
            "!",
            "?",
            ":",
            ";",
            "-",
            "_",
            "(",
            ")",
            "[",
            "]",
            "{",
            "}",
            '"',
            "'",
            "`",
            "/",
            "\\",
            "@",
            "#",
            "$",
            "%",
            "^",
            "&",
            "*",
            "+",
            "=",
            "<",
            ">",
            "|",
            "~",

            # ----------------------------------------------------------------
            # Aether
            # ----------------------------------------------------------------
            "aether",
            "ai",
            "core",
            "orchestrator",
            "orchestration",
            "assistant",
            "agentic",
            "automation",
            "automations",
            "project",
            "projects",
            "workspace",
            "workspaces",
            "knowledge",
            "rag",
            "retrieval",
            "memory",
            "memories",
            "context",
            "contextual",
            "task",
            "tasks",
            "goal",
            "goals",
            "calendar",
            "user",
            "active",
            "pending",
            "completed",
            "create",
            "delete",
            "list",
            "run",
            "update",
            "execute",
            "execution",
            "schedule",
            "scheduled",
            "trigger",
            "triggers",
            "action",
            "actions",
            "tool",
            "tools",
            "verify",
            "verification",
            "verified",
            "database",
            "postgres",
            "postgresql",
            "prisma",
            "orm",
            "isolation",
            "tenant",
            "security",
            "authorization",
            "auth",
            "mfa",
            "permission",
            "token",
            "tokens",
            "inference",
            "neural",
            "transformer",
            "weights",
            "checkpoint",
            "status",
            "state",
            "success",
            "error",
            "confidence",
            "high",
            "medium",
            "low",
            "insufficient",
            "information",
            "reliably",
            "cannot",
            "refusal",
            "clarify",
            "clarification",

            # ----------------------------------------------------------------
            # Programming
            # ----------------------------------------------------------------
            "typescript",
            "javascript",
            "python",
            "code",
            "coding",
            "function",
            "const",
            "let",
            "var",
            "return",
            "interface",
            "type",
            "async",
            "await",
            "promise",
            "class",
            "import",
            "export",
            "default",
            "api",
            "rest",
            "http",
            "get",
            "post",
            "put",
            "endpoint",
            "request",
            "response",
            "json",
            "schema",
            "backend",
            "frontend",
            "server",
            "client",
            "service",
            "model",
            "view",
            "controller",
            "component",
            "react",
            "node",
            "express",
            "sql",
            "query",
            "select",
            "insert",
            "try",
            "catch",
            "throw",
            "exception",
            "result",
            "ok",
            "err",

            # ----------------------------------------------------------------
            # Planning / writing
            # ----------------------------------------------------------------
            "plan",
            "planning",
            "roadmap",
            "milestone",
            "milestones",
            "deliverable",
            "deliverables",
            "summary",
            "summarize",
            "summarization",
            "briefing",
            "agenda",
            "review",
            "status",
            "report",
            "progress",
            "blocker",
            "blockers",
            "priority",
            "deadline",
            "sprint",
            "team",
            "stakeholder",
            "stakeholders",
            "email",
            "subject",
            "regards",
        ]

        for token in common_vocab:
            self._add_token(token)

    # ========================================================================
    # VOCABULARY CONTROL
    # ========================================================================

    def freeze(self) -> None:
        """Prevent any future vocabulary mutation."""

        self.frozen = True

    def unfreeze(self) -> None:
        """Allow vocabulary growth for training/vocabulary construction."""

        self.frozen = False

    def _add_token(self, token: str) -> int:
        """
        Add a token to the vocabulary.

        If frozen, NEVER mutate the vocabulary.
        """

        if not token:
            return UNK_TOKEN_ID

        existing = self.token_to_id.get(token)

        if existing is not None:
            return existing

        if self.frozen:
            return UNK_TOKEN_ID

        next_id = self.next_id

        self.token_to_id[token] = next_id
        self.id_to_token[next_id] = token
        self.next_id += 1

        return next_id

    # ========================================================================
    # ENCODING
    # ========================================================================

    def tokenize(self, text: str) -> List[str]:
        """
        Convert text into deterministic lexical tokens.

        This method NEVER changes the vocabulary.
        """

        if not isinstance(text, str):
            raise TypeError("text must be a string")

        if not text:
            return []

        return self._TOKEN_PATTERN.findall(text)

    def encode(
        self,
        text: str,
        add_special_tokens: bool = False,
        max_length: Optional[int] = None,
        pad_to_max: bool = False,
    ) -> List[int]:
        """
        Encode text into token IDs.

        In frozen mode:
            unknown tokens -> UNK_TOKEN_ID

        In unfrozen mode:
            unknown tokens are added to the vocabulary.
        """

        if not isinstance(text, str):
            raise TypeError("text must be a string")

        if max_length is not None:
            if max_length <= 0:
                raise ValueError("max_length must be greater than zero")

        tokens = self.tokenize(text)

        ids: List[int] = []

        if add_special_tokens:
            ids.append(USER_TOKEN_ID)

        for token in tokens:

            # Exact token lookup first.
            token_id = self.token_to_id.get(token)

            if token_id is not None:
                ids.append(token_id)
                continue

            # Case-insensitive lookup for normal words.
            lowered = token.lower()

            token_id = self.token_to_id.get(lowered)

            if token_id is not None:
                ids.append(token_id)
                continue

            # Frozen inference/evaluation:
            # NEVER create a new vocabulary ID.
            if self.frozen:
                ids.append(UNK_TOKEN_ID)
                continue

            # Training:
            # Vocabulary may grow.
            ids.append(self._add_token(lowered))

        if add_special_tokens:
            ids.append(EOS_TOKEN_ID)

        # Truncation.
        if max_length is not None and len(ids) > max_length:
            ids = ids[:max_length]

        # Padding.
        if (
            pad_to_max
            and max_length is not None
            and len(ids) < max_length
        ):
            ids.extend(
                [PAD_TOKEN_ID] * (max_length - len(ids))
            )

        return ids

    def batch_encode(
        self,
        texts: List[str],
        max_length: Optional[int] = None,
        pad_to_max: bool = True,
    ) -> List[List[int]]:
        """Encode multiple strings deterministically."""

        if not isinstance(texts, list):
            raise TypeError("texts must be a list of strings")

        return [
            self.encode(
                text,
                add_special_tokens=False,
                max_length=max_length,
                pad_to_max=pad_to_max,
            )
            for text in texts
        ]

    # ========================================================================
    # DECODING
    # ========================================================================

    def decode(
        self,
        ids: Iterable[int],
        skip_special_tokens: bool = True,
    ) -> str:
        """
        Convert token IDs back into readable text.

        Unknown IDs are rendered as <unk>.
        """

        if ids is None:
            return ""

        tokens: List[str] = []

        for token_id in ids:

            if not isinstance(token_id, int):
                raise TypeError(
                    f"Token IDs must be integers, got {type(token_id).__name__}"
                )

            token = self.id_to_token.get(
                token_id,
                "<unk>",
            )

            if (
                skip_special_tokens
                and token in self.special_tokens
            ):
                continue

            tokens.append(token)

        if not tokens:
            return ""

        result = ""

        for index, token in enumerate(tokens):

            if index == 0:
                result = token
                continue

            previous = tokens[index - 1]

            # Newline handling.
            if token == "\n":
                result += "\n"
                continue

            if previous == "\n":
                result += token
                continue

            # Punctuation should attach to previous token.
            if token in self._NO_SPACE_BEFORE:
                result += token
                continue

            # Opening brackets should not have a space after them.
            if previous in self._NO_SPACE_AFTER:
                result += token
                continue

            result += " " + token

        return result.strip()

    # ========================================================================
    # VOCABULARY VALIDATION
    # ========================================================================

    def validate(self) -> None:
        """
        Validate tokenizer internal consistency.

        Raises ValueError for corrupted vocabularies.
        """

        if not self.token_to_id:
            raise ValueError("Tokenizer vocabulary is empty")

        # Check special tokens.
        for token, expected_id in SPECIAL_TOKEN_IDS.items():

            actual_id = self.token_to_id.get(token)

            if actual_id != expected_id:
                raise ValueError(
                    f"Special token ID mismatch: "
                    f"{token!r}: expected {expected_id}, "
                    f"got {actual_id}"
                )

            reverse_token = self.id_to_token.get(expected_id)

            if reverse_token != token:
                raise ValueError(
                    f"Reverse vocabulary mismatch for {token!r}"
                )

        # Check duplicate IDs.
        ids = list(self.token_to_id.values())

        if len(ids) != len(set(ids)):
            raise ValueError(
                "Vocabulary contains duplicate token IDs"
            )

        # Check reverse mapping.
        for token, token_id in self.token_to_id.items():

            reverse_token = self.id_to_token.get(token_id)

            if reverse_token != token:
                raise ValueError(
                    f"Vocabulary mapping mismatch: "
                    f"{token!r} -> {token_id}, "
                    f"reverse mapping gives {reverse_token!r}"
                )

        # Check IDs are non-negative integers.
        for token, token_id in self.token_to_id.items():

            if not isinstance(token_id, int):
                raise ValueError(
                    f"Token ID for {token!r} is not an integer"
                )

            if token_id < 0:
                raise ValueError(
                    f"Token ID for {token!r} is negative"
                )

        # IDs should be contiguous.
        expected_ids = set(range(len(ids)))
        actual_ids = set(ids)

        if actual_ids != expected_ids:
            missing = sorted(expected_ids - actual_ids)
            extra = sorted(actual_ids - expected_ids)

            raise ValueError(
                "Vocabulary IDs are not contiguous. "
                f"Missing={missing[:10]}, Extra={extra[:10]}"
            )

        self.next_id = len(self.token_to_id)

    def validate_against_vocab_size(
        self,
        model_vocab_size: int,
    ) -> None:
        """
        Ensure tokenizer and model use exactly the same vocabulary size.

        This is intentionally strict.

        A mismatch means the tokenizer and checkpoint are incompatible.
        """

        if not isinstance(model_vocab_size, int):
            raise TypeError(
                "model_vocab_size must be an integer"
            )

        if model_vocab_size <= 0:
            raise ValueError(
                "model_vocab_size must be greater than zero"
            )

        tokenizer_size = self.vocab_size

        if tokenizer_size != model_vocab_size:
            raise ValueError(
                "TOKENIZER_CHECKPOINT_VOCAB_MISMATCH: "
                f"tokenizer vocab_size={tokenizer_size}, "
                f"model vocab_size={model_vocab_size}. "
                "Load the vocabulary that was used when the checkpoint "
                "was trained. Do not dynamically expand the vocabulary."
            )

    # ========================================================================
    # VOCABULARY PERSISTENCE
    # ========================================================================

    def save_vocab(self, file_path: str) -> None:
        """
        Save the complete vocabulary and metadata.

        JSON format remains compatible with the previous implementation:
        token -> integer ID.
        """

        if not file_path:
            raise ValueError("file_path is required")

        self.validate()

        directory = os.path.dirname(
            os.path.abspath(file_path)
        )

        os.makedirs(
            directory,
            exist_ok=True,
        )

        with open(
            file_path,
            "w",
            encoding="utf-8",
        ) as file:

            json.dump(
                self.token_to_id,
                file,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )

    def load_vocab(self, file_path: str) -> None:
        """
        Load an authoritative vocabulary.

        Existing vocabulary is replaced rather than merged.

        This prevents accidental mixing of two vocabularies.
        """

        if not file_path:
            raise ValueError("file_path is required")

        if not os.path.isfile(file_path):
            raise FileNotFoundError(
                f"Vocabulary file not found: {file_path}"
            )

        with open(
            file_path,
            "r",
            encoding="utf-8",
        ) as file:

            vocab = json.load(file)

        if not isinstance(vocab, dict):
            raise ValueError(
                "Vocabulary file must contain a JSON object"
            )

        new_token_to_id: Dict[str, int] = {}
        new_id_to_token: Dict[int, str] = {}

        for token, token_id in vocab.items():

            if not isinstance(token, str):
                raise ValueError(
                    "Vocabulary token must be a string"
                )

            # JSON numeric values normally become Python ints,
            # but validate explicitly.
            if not isinstance(token_id, int):
                raise ValueError(
                    f"Vocabulary ID for {token!r} must be an integer"
                )

            if token_id < 0:
                raise ValueError(
                    f"Vocabulary ID for {token!r} cannot be negative"
                )

            if token_id in new_id_to_token:
                raise ValueError(
                    f"Duplicate vocabulary ID {token_id}: "
                    f"{new_id_to_token[token_id]!r} and {token!r}"
                )

            new_token_to_id[token] = token_id
            new_id_to_token[token_id] = token

        # Replace existing vocabulary only after parsing succeeds.
        self.token_to_id = new_token_to_id
        self.id_to_token = new_id_to_token

        self.next_id = (
            max(self.id_to_token.keys(), default=-1) + 1
        )

        self.validate()

    # ========================================================================
    # HASHING
    # ========================================================================

    def get_vocab_hash(self) -> str:
        """
        Return deterministic SHA-256 hash of the vocabulary.

        The hash is stable regardless of JSON formatting.
        """

        self.validate()

        canonical_pairs = [
            [token, token_id]
            for token, token_id in sorted(
                self.token_to_id.items(),
                key=lambda item: item[0],
            )
        ]

        serialized = json.dumps(
            canonical_pairs,
            ensure_ascii=False,
            separators=(",", ":"),
        )

        return hashlib.sha256(
            serialized.encode("utf-8")
        ).hexdigest()

    # ========================================================================
    # CHECKPOINT COMPATIBILITY
    # ========================================================================

    def validate_checkpoint_compatibility(
        self,
        *,
        checkpoint_vocab_size: int,
        checkpoint_vocab_hash: Optional[str] = None,
    ) -> None:
        """
        Validate tokenizer against checkpoint metadata.

        Raises immediately if the tokenizer cannot safely be used
        with the checkpoint.
        """

        self.validate()

        self.validate_against_vocab_size(
            checkpoint_vocab_size
        )

        if checkpoint_vocab_hash is not None:

            actual_hash = self.get_vocab_hash()

            if actual_hash != checkpoint_vocab_hash:
                raise ValueError(
                    "TOKENIZER_CHECKPOINT_HASH_MISMATCH: "
                    f"tokenizer hash={actual_hash}, "
                    f"checkpoint hash={checkpoint_vocab_hash}. "
                    "The tokenizer vocabulary is not the vocabulary "
                    "used to train this checkpoint."
                )

    # ========================================================================
    # PROPERTIES
    # ========================================================================

    @property
    def vocab_size(self) -> int:
        """Number of tokens in the vocabulary."""

        return len(self.token_to_id)

    @property
    def is_frozen(self) -> bool:
        """Whether vocabulary mutation is disabled."""

        return self.frozen

    # ========================================================================
    # DEBUG / INFORMATION
    # ========================================================================

    def get_info(self) -> Dict[str, Any]:
        """Return diagnostic information about the tokenizer."""

        return {
            "version": self.VERSION,
            "vocab_size": self.vocab_size,
            "vocab_hash": self.get_vocab_hash(),
            "frozen": self.frozen,
            "special_tokens": dict(SPECIAL_TOKEN_IDS),
            "next_id": self.next_id,
        }


__all__ = [
    "AetherTokenizer",
    "SPECIAL_TOKENS",
    "SPECIAL_TOKEN_IDS",
    "PAD_TOKEN_ID",
    "UNK_TOKEN_ID",
    "EOS_TOKEN_ID",
    "SYSTEM_TOKEN_ID",
    "USER_TOKEN_ID",
    "ASSISTANT_TOKEN_ID",
    "TOOL_TOKEN_ID",
    "EVIDENCE_TOKEN_ID",
]